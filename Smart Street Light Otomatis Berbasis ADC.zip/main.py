#define LDR_PIN   36      // Pin ADC1_CH0 untuk sensor LDR
#define LAMP_PIN  5       // Pin output lampu
#define THRESHOLD 2000    // Ambang batas nilai ADC

void setup() {
    Serial.begin(115200);

    pinMode(LAMP_PIN, OUTPUT);

    Serial.println("Sistem Otomatisasi Lampu Jalan Ready.");
}

void loop() {
    // Membaca nilai sensor LDR
    int ldrValue = analogRead(LDR_PIN);

    // Menampilkan nilai ADC pada Serial Monitor
    Serial.print("Nilai Cahaya Analog (ADC): ");
    Serial.println(ldrValue);

    // Mengecek kondisi intensitas cahaya
    if (ldrValue > THRESHOLD) {
        // Kondisi gelap: lampu menyala
        digitalWrite(LAMP_PIN, HIGH);
        Serial.println("Status: GELAP -> Lampu Menyala [ON]");
    } else {
        // Kondisi terang: lampu mati
        digitalWrite(LAMP_PIN, LOW);
        Serial.println("Status: TERANG -> Lampu Mati [OFF]");
    }

    // Jeda pembacaan selama 1 detik
    delay(1000);
}