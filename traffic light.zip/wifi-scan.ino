// --- Sesuaikan pin ini kalau di fotomu beda angka ---
// Kiri Atas
const int merah_ka = 19;
const int kuning_ka = 18;
const int hijau_ka = 5;

// Kanan Atas
const int merah_kaa = 2;
const int kuning_kaa = 15;
const int hijau_kaa = 4;

// Kiri Bawah
const int merah_kb = 25;
const int kuning_kb = 26;
const int hijau_kb = 27;

// Kanan Bawah
const int merah_kbb = 13;
const int kuning_kbb = 12;
const int hijau_kbb = 14;

void setup() {
  pinMode(merah_ka, OUTPUT); pinMode(kuning_ka, OUTPUT); pinMode(hijau_ka, OUTPUT);
  pinMode(merah_kaa, OUTPUT); pinMode(kuning_kaa, OUTPUT); pinMode(hijau_kaa, OUTPUT);
  pinMode(merah_kb, OUTPUT); pinMode(kuning_kb, OUTPUT); pinMode(hijau_kb, OUTPUT);
  pinMode(merah_kbb, OUTPUT); pinMode(kuning_kbb, OUTPUT); pinMode(hijau_kbb, OUTPUT);
}

void loop() {
  // 1. SEMUA MERAH (Berhenti)
  semuaMerah();
  delay(3000);

  // 2. KIRI ATAS & KANAN BAWAH HIJAU, YANG LAIN MERAH
  hijau_ka_kbb();
  delay(5000);

  // 3. KUNING PERSIAPAN
  semuaKuning();
  delay(2000);

  // 4. KANAN ATAS & KIRI BAWAH HIJAU
  hijau_kaa_kb();
  delay(5000);
}

void semuaMerah(){
  digitalWrite(merah_ka, HIGH); digitalWrite(kuning_ka, LOW); digitalWrite(hijau_ka, LOW);
  digitalWrite(merah_kaa, HIGH); digitalWrite(kuning_kaa, LOW); digitalWrite(hijau_kaa, LOW);
  digitalWrite(merah_kb, HIGH); digitalWrite(kuning_kb, LOW); digitalWrite(hijau_kb, LOW);
  digitalWrite(merah_kbb, HIGH); digitalWrite(kuning_kbb, LOW); digitalWrite(hijau_kbb, LOW);
}
void semuaKuning(){
  digitalWrite(merah_ka, LOW); digitalWrite(kuning_ka, HIGH); digitalWrite(hijau_ka, LOW);
  digitalWrite(merah_kaa, LOW); digitalWrite(kuning_kaa, HIGH); digitalWrite(hijau_kaa, LOW);
  digitalWrite(merah_kb, LOW); digitalWrite(kuning_kb, HIGH); digitalWrite(hijau_kb, LOW);
  digitalWrite(merah_kbb, LOW); digitalWrite(kuning_kbb, HIGH); digitalWrite(hijau_kbb, LOW);
}
void hijau_ka_kbb(){
  digitalWrite(merah_ka, LOW); digitalWrite(kuning_ka, LOW); digitalWrite(hijau_ka, HIGH);
  digitalWrite(merah_kbb, LOW); digitalWrite(kuning_kbb, LOW); digitalWrite(hijau_kbb, HIGH);
  digitalWrite(merah_kaa, HIGH); digitalWrite(kuning_kaa, LOW); digitalWrite(hijau_kaa, LOW);
  digitalWrite(merah_kb, HIGH); digitalWrite(kuning_kb, LOW); digitalWrite(hijau_kb, LOW);
}
void hijau_kaa_kb(){
  digitalWrite(merah_kaa, LOW); digitalWrite(kuning_kaa, LOW); digitalWrite(hijau_kaa, HIGH);
  digitalWrite(merah_kb, LOW); digitalWrite(kuning_kb, LOW); digitalWrite(hijau_kb, HIGH);
  digitalWrite(merah_ka, HIGH); digitalWrite(kuning_ka, LOW); digitalWrite(hijau_ka, LOW);
  digitalWrite(merah_kbb, HIGH); digitalWrite(kuning_kbb, LOW); digitalWrite(hijau_kbb, LOW);
}